class LibrosController < ActionController::Base
  def index
        @libros = Libro.all
    end
    def show
      @libro = Libro.find(params[:id])
    end
    def new
    @libro = Libro.new
    end
    def edit
        @libro = Libro.find(params[:id])
    end

    def destroy
      @libro = Libro.find(params[:id])
      @libro.destroy
      redirect_to libros_path
    end

    def update
      @libro = Libro.find(params[:id])
      if @libro.update(libro_params)
        redirect_to @libro
      else
        render :edit
    end
  end
    def create

  #@libro = current_user.libros.new(libro_params)//** este cambio es hasta el final
      @libro = Libro.new(libro_params)
  	#@libro = Libro.new(title: params[:libro][:title], autor: params[:libro][:autor])
  		if @libro.save
  			redirect_to @libro
  		else
  			render :new
  		end
  	end

    private
    def libro_params
      params.require(:libro).permit(:titulo,:autor,:editorial,:num_paginas)
    end
end
